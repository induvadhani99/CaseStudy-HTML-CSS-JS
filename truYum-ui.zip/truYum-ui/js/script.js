function add(){
    document.getElementById("noti").innerHTML="Item added to Cart successfully"
}
function del(){
    document.getElementById("noti").innerHTML="Item removed from Cart successfully"
}